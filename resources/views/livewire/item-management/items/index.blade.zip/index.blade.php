<?php

use Livewire\Volt\Component;
use App\Models\Item;
use App\Models\Price;
use App\Models\Note;
use App\Helpers\ItemViewModel;

new class extends Component {
    public $items;
    public $selectedUnit = [];
    public $displayItemData = [];
    public $priceTypes;
    public $noteTypes;

    public function mount()
    {
        $this->items = Item::with([
            'units' => function ($query) { $query->orderBy('pivot_u_val'); },
            'prices',
            'barcodes',
            'notes'
        ])->get();

        $this->priceTypes = Price::all()->pluck('name', 'id');
        $this->noteTypes = Note::all()->pluck('name', 'id');

        foreach ($this->items as $item) {
            $defaultUnit = $item->units->sortBy('pivot.u_val')->first();
            $this->selectedUnit[$item->id] = $defaultUnit ? $defaultUnit->id : null;
            $this->calculateAndStoreDisplayData($item->id);
        }
    }

    public function calculateAndStoreDisplayData($itemId)
    {
        $item = $this->items->firstWhere('id', $itemId);
        if (!$item) {
            $this->displayItemData[$itemId] = [];
            return;
        }

        $selectedUnitId = $this->selectedUnit[$itemId] ?? null;
        $viewModel = new ItemViewModel($item, $selectedUnitId);

        $unitSalePricesData = [];
        if ($selectedUnitId) {
            $rawPrices = $viewModel->getUnitSalePrices();
            foreach ($this->priceTypes as $priceTypeId => $priceTypeName) {
                $unitSalePricesData[$priceTypeId] = $rawPrices[$priceTypeId] ?? ['name' => $priceTypeName, 'price' => null];
            }
        }

        $this->displayItemData[$itemId] = [
            'id' => $item->id,
            'code' => $item->code,
            'name' => $item->name,
            'unitOptions' => $viewModel->getUnitOptions(),
            'formattedQuantity' => $viewModel->getFormattedQuantity(),
            'unitCostPrice' => $viewModel->getUnitCostPrice(),
            'quantityCost' => $viewModel->getQuantityCost(),
            'unitSalePrices' => $unitSalePricesData,
            'unitBarcodes' => $selectedUnitId ? $viewModel->getUnitBarcode() : [],
            'itemNotes' => $item->notes->mapWithKeys(function ($note) {
                return [$note->id => $note->pivot->note_detail_name];
            })->all(),
        ];
    }

    public function updated($propertyName, $value)
    {
        if (str_starts_with($propertyName, 'selectedUnit.')) {
            $parts = explode('.', $propertyName);
            $itemId = (int) $parts[1];

            if (isset($this->selectedUnit[$itemId])) {
                $this->calculateAndStoreDisplayData($itemId);
            }
        }
    }

    public function getComputedKey($itemId)
    {
        return 'item-' . $itemId . '-' . ($this->selectedUnit[$itemId] ?? 'no-unit');
    }

    public function edit($itemId)
    {
        // Add your edit logic here, e.g., redirect or show modal
        // redirect()->route('items.edit', $itemId);
    }

    public function delete($itemId)
    {
        // Add your delete logic here
        // Item::find($itemId)->delete();
        // Refresh items or remove from collections
    }
}; ?>

<div>
    @php
        include_once app_path('Helpers/FormatHelper.php');
    @endphp
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <a href="{{ route('items.create') }}" class="btn btn-primary font-family-cairo fw-bold">
                        {{ __('Add New') }}
                        <i class="fas fa-plus me-2"></i>
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th class="font-family-cairo fw-bold">#</th>
                                    <th class="font-family-cairo fw-bold">الكود</th>
                                    <th class="font-family-cairo fw-bold">الاسم</th>
                                    <th class="font-family-cairo fw-bold">الوحدات</th>
                                    <th class="font-family-cairo fw-bold">الكميه</th>
                                    <th class="font-family-cairo fw-bold">التكلفه</th>
                                    <th class="font-family-cairo fw-bold">تكلفه الكميه</th>
                                    @foreach ($this->priceTypes as $priceId => $priceName)
                                        <th class="font-family-cairo fw-bold">{{ $priceName }}</th>
                                    @endforeach
                                    <th class="font-family-cairo fw-bold">الباركود</th>
                                    @foreach ($this->noteTypes as $noteId => $noteName)
                                        <th class="font-family-cairo fw-bold">{{ $noteName }}</th>
                                    @endforeach
                                    <th class="font-family-cairo fw-bold">العمليات</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($displayItemData as $itemId => $itemData)
                                    @if (!empty($itemData))
                                    <tr wire:key="{{ $this->getComputedKey($itemId) }}">
                                        <td class="font-family-cairo fw-bold">{{ $loop->iteration }}</td>
                                        <td class="font-family-cairo fw-bold">{{ $itemData['code'] }}</td>
                                        <td class="font-family-cairo fw-bold">{{ $itemData['name'] }}</td>
                                        <td class="font-family-cairo fw-bold">
                                            @if (!empty($itemData['unitOptions']))
                                            <select class="form-select font-family-cairo fw-bold font-14"
                                                wire:model.live="selectedUnit.{{ $itemId }}">
                                                @foreach ($itemData['unitOptions'] as $option)
                                                    <option value="{{ $option['value'] }}">{{ $option['label'] }}</option>
                                                @endforeach
                                            </select>
                                            @else
                                            <span class="font-family-cairo fw-bold font-14">لا يوجد وحدات</span>
                                            @endif
                                        </td>
                                        <td class="text-center fw-bold">
                                            @php $fq = $itemData['formattedQuantity']; @endphp
                                            {{ $fq['quantity']['integer'] }}
                                            @if (isset($fq['quantity']['remainder']) && $fq['quantity']['remainder'] > 0 && $fq['unitName'] !== $fq['smallerUnitName'])
                                                [{{ $fq['quantity']['remainder'] }} {{ $fq['smallerUnitName'] }}]
                                            @endif
                                        </td>
                                        <td class="text-center fw-bold">
                                            {{ formatCurrency($itemData['unitCostPrice']) }}
                                        </td>
                                        <td class="text-center fw-bold">
                                            {{ formatCurrency($itemData['quantityCost']) }}
                                        </td>

                                        {{-- Prices --}}
                                        @foreach ($this->priceTypes as $priceTypeId => $priceTypeName)
                                            <td class="font-family-cairo fw-bold">
                                                {{ isset($itemData['unitSalePrices'][$priceTypeId]['price']) ? formatCurrency($itemData['unitSalePrices'][$priceTypeId]['price']) : 'N/A' }}
                                            </td>
                                        @endforeach

                                        <td class="font-family-cairo fw-bold">
                                            @if (!empty($itemData['unitBarcodes']))
                                            <select class="form-select font-family-cairo fw-bold font-14">
                                                @foreach ($itemData['unitBarcodes'] as $barcode)
                                                    <option value="{{ $barcode['barcode'] }}">{{ $barcode['barcode'] }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            @else
                                             <span class="font-family-cairo fw-bold font-14">لا يوجد</span>
                                            @endif
                                        </td>

                                        {{-- Notes --}}
                                        @foreach ($this->noteTypes as $noteTypeId => $noteTypeName)
                                            <td class="font-family-cairo fw-bold">
                                                {{ $itemData['itemNotes'][$noteTypeId] ?? '' }}
                                            </td>
                                        @endforeach

                                        <td>
                                            <a wire:click="edit({{ $itemId }})"><i
                                                    class="las la-pen text-success font-20"></i></a>
                                            <a wire:click="delete({{ $itemId }})"
                                                onclick="confirm('هل أنت متأكد من حذف هذا الصنف؟') || event.stopImmediatePropagation()">
                                                <i class="las la-trash-alt text-danger font-20"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    @endif
                                @empty
                                    @php
                                        $colspan = 7 + count($this->priceTypes) + 1 + count($this->noteTypes) + 1;
                                    @endphp
                                    <tr>
                                        <td colspan="{{ $colspan }}"
                                            class="text-center font-family-cairo fw-bold">لا يوجد سجلات
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
